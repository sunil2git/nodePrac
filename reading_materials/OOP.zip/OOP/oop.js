// class Car {
//   constructor(brand, model, color) {
//     this.brand = brand;
//     this.model = model;
//     this.color = color;
//   }

//   myfun() {
//     console.log(`my brand is ${this.brand} and model is ${this.model} and car color is ${this.color}`);
//   }
// }

// const myCar = new Car('Toyota', 'Camry', 'white');
// myCar.myfun();

//single
// class classA {
//   constructor(name) {
//     this.name = name;
//   }
// }

// class classB extends classA {
//   constructor(name, email) {
//     super(name);
//     this.email = email;
//   }
// }

// //multilevel

// class classA {
//   constructor(name) {
//     this.name = name;
//   }
// }

// class classB extends classA {
//   constructor(name, email) {
//     super(name);
//     this.email = email;
//   }
// }

// class classC extends classB {
//   constructor(name, email) {
//     super(name);
//     this.email = email;
//   }
// }
